package com.javaex.ex01;

public class PhoneApp {

    public static void main(String[] args) {

    	
    }

}